import Link from "next/link"

export default function RankingsPage() {
  return (
    <div className="min-h-screen bg-[#f9f9f9] text-[#111] font-serif">
      <header className="border-b border-gray-300 py-6">
        <div className="container mx-auto px-4">
          <h1 className="text-2xl font-normal tracking-tight">Tabletop Library Rankings</h1>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-1 border border-gray-300">
          {/* Left Column - Games List */}
          <section className="bg-[#f9f9f9] p-6 md:p-8 border-b md:border-b-0 md:border-r border-gray-300">
            <div className="relative">
              <span className="absolute top-0 left-0 text-xs text-gray-500">(01.1)</span>
              <h2 className="text-xl font-normal text-center border-b border-gray-300 pb-2 mb-6">Most Voted Games</h2>

              <div className="space-y-4">
                <div className="grid grid-cols-[1fr_auto] gap-2 items-baseline">
                  <div className="text-sm text-gray-500 border-b border-dotted border-gray-300 pb-1">
                    Name - Secondary Category
                  </div>
                  <div className="text-sm text-gray-500 border-b border-dotted border-gray-300 pb-1 text-right">
                    Votes
                  </div>
                </div>

                <GameListItem name="Catan" category="Engine Builder" votes={12} />
                <GameListItem name="Gloomhaven" category="Campaign" votes={10} />
                <GameListItem name="Wingspan" category="Engine Builder" votes={9} />
                <GameListItem name="Pandemic" category="Cooperative" votes={8} />
                <GameListItem name="Terraforming Mars" category="Engine Builder" votes={7} />
                <GameListItem name="Scythe" category="Area Control" votes={6} />
                <GameListItem name="Azul" category="Abstract" votes={5} />
                <GameListItem name="7 Wonders" category="Card Drafting" votes={5} />
                <GameListItem name="Ticket to Ride" category="Set Collection" votes={4} />
                <GameListItem name="Codenames" category="Party" votes={4} />
                <GameListItem name="Spirit Island" category="Cooperative" votes={3} />
                <GameListItem name="Brass: Birmingham" category="Economic" votes={3} />
                <GameListItem name="Root" category="Asymmetric" votes={2} />
                <GameListItem name="Everdell" category="Worker Placement" votes={2} />
                <GameListItem name="Ark Nova" category="Card Drafting" votes={1} />
              </div>

              <div className="mt-8 flex justify-between text-xs text-gray-500">
                <span>GAMES</span>
                <span>TABLETOP LIBRARY</span>
              </div>
            </div>
          </section>

          {/* Right Column - Categories List */}
          <section className="bg-[#f9f9f9] p-6 md:p-8">
            <div className="relative">
              <span className="absolute top-0 left-0 text-xs text-gray-500">(01.2)</span>
              <h2 className="text-xl font-normal text-center border-b border-gray-300 pb-2 mb-6">Categories</h2>

              <p className="text-sm max-w-[80%] my-6">
                We organize games by category to encourage your curiosity in browsing games. These are the current votes
                by game category.
              </p>

              <div className="space-y-6">
                <CategoryListItem
                  code="100"
                  name="ABSTRACT STRATEGY"
                  description="For games with deep strategic thinking and no theming"
                  count={12}
                />
                <CategoryListItem
                  code="200"
                  name="FAMILY FAVORITES"
                  description="Accessible, widely appealing games"
                  count={15}
                />
                <CategoryListItem code="300" name="PARTY TIME" description="Social, high-interaction games" count={8} />
                <CategoryListItem
                  code="400"
                  name="COOPERATIVE"
                  description="Games where players work together"
                  count={10}
                />
                <CategoryListItem
                  code="500"
                  name="EURO STRATEGY"
                  description="Resource management, optimization"
                  count={18}
                />
                <CategoryListItem
                  code="600"
                  name="CONFLICT & POLITICS"
                  description="Direct competition, area control"
                  count={9}
                />
                <CategoryListItem
                  code="700"
                  name="CARDS & DECKS"
                  description="Deck-building, card-driven mechanics"
                  count={14}
                />
                <CategoryListItem
                  code="800"
                  name="STORY & LEGACY"
                  description="Narrative-driven, campaign-style games"
                  count={7}
                />
              </div>

              <div className="mt-8 flex justify-between text-xs text-gray-500">
                <span>CATEGORIES</span>
                <span>TABLETOP LIBRARY</span>
              </div>
            </div>
          </section>
        </div>
      </main>
    </div>
  )
}

function GameListItem({ name, category, votes }: { name: string; category: string; votes: number }) {
  return (
    <div className="grid grid-cols-[1fr_auto] gap-2 items-baseline">
      <Link href="#" className="hover:underline">
        <span className="font-medium">{name}</span>
        <span className="text-gray-600"> - {category}</span>
      </Link>
      <span className="font-mono text-right">{votes}</span>
    </div>
  )
}

function CategoryListItem({
  code,
  name,
  description,
  count,
}: { code: string; name: string; description: string; count: number }) {
  return (
    <div>
      <div className="flex justify-between items-baseline mb-1">
        <div>
          <span className="font-mono text-sm mr-2">{code}</span>
          <span className="font-medium">{name}:</span>
        </div>
        <span className="font-mono">{count}</span>
      </div>
      <p className="text-sm text-gray-600 ml-8">{description}</p>
    </div>
  )
}
